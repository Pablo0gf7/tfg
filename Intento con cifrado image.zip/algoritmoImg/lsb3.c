#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#include "lsb3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sodium.h>

void embedMessage(const char *imagePath, const char *message, const char *outputPath, const char *key)
{
    if (sodium_init() < 0) {
        fprintf(stderr, "libsodium init failed.\n");
        return;
    }

    int width, height, channels;
    unsigned char *img = stbi_load(imagePath, &width, &height, &channels, 0);
    if (!img) {
        fprintf(stderr, "Error loading image: %s\n", imagePath);
        return;
    }
    if (channels < 3) {
        fprintf(stderr, "Image must have at least 3 channels (RGB).\n");
        stbi_image_free(img);
        return;
    }

    unsigned char nonce[crypto_secretbox_NONCEBYTES];
    randombytes_buf(nonce, sizeof nonce);

    unsigned char key_bin[crypto_secretbox_KEYBYTES];
    crypto_generichash(key_bin, sizeof key_bin, (const unsigned char *)key, strlen(key), NULL, 0);

    size_t messageLen = strlen(message);
    size_t cipherLen = messageLen + crypto_secretbox_MACBYTES;
    unsigned char *cipher = malloc(cipherLen);
    crypto_secretbox_easy(cipher, (const unsigned char *)message, messageLen, nonce, key_bin);

    size_t totalLen = crypto_secretbox_NONCEBYTES + cipherLen;
    unsigned char *finalData = malloc(totalLen);
    memcpy(finalData, nonce, crypto_secretbox_NONCEBYTES);
    memcpy(finalData + crypto_secretbox_NONCEBYTES, cipher, cipherLen);

    size_t bitsNeeded = totalLen * 8;
    size_t bitsAvailable = width * height * 3;
    if (bitsNeeded > bitsAvailable) {
        fprintf(stderr, "Encrypted message too large for image.\n");
        free(cipher);
        free(finalData);
        stbi_image_free(img);
        return;
    }

    size_t bitIndex = 0;
    for (size_t i = 0; i < totalLen; ++i) {
        for (int bit = 7; bit >= 0; --bit) {
            unsigned char bitValue = (finalData[i] >> bit) & 1;
            size_t pixel = bitIndex / 3;
            size_t color = bitIndex % 3;
            img[pixel * channels + color] = (img[pixel * channels + color] & ~1) | bitValue;
            bitIndex++;
        }
    }

    if (!stbi_write_png(outputPath, width, height, channels, img, width * channels)) {
        fprintf(stderr, "Error saving image to %s\n", outputPath);
    }

    free(cipher);
    free(finalData);
    stbi_image_free(img);
}


char *extractMessage(const char *imagePath, const char *key)
{
    if (sodium_init() < 0) {
        fprintf(stderr, "libsodium init failed.\n");
        return NULL;
    }

    int width, height, channels;
    unsigned char *img = stbi_load(imagePath, &width, &height, &channels, 0);
    if (!img) {
        fprintf(stderr, "Error loading image: %s\n", imagePath);
        return NULL;
    }
    if (channels < 3) {
        fprintf(stderr, "Image must have at least 3 channels (RGB).\n");
        stbi_image_free(img);
        return NULL;
    }

    size_t maxBits = width * height * 3;
    size_t maxBytes = maxBits / 8;

    unsigned char *data = malloc(maxBytes);
    size_t bitIndex = 0;
    for (size_t i = 0; i < maxBytes; ++i) {
        unsigned char byte = 0;
        for (int bit = 7; bit >= 0; --bit) {
            size_t pixel = bitIndex / 3;
            size_t color = bitIndex % 3;
            unsigned char bitValue = img[pixel * channels + color] & 1;
            byte |= (bitValue << bit);
            bitIndex++;
        }
        data[i] = byte;
    }

    unsigned char *nonce = data;
    unsigned char *cipher = data + crypto_secretbox_NONCEBYTES;
    size_t cipherLen = maxBytes - crypto_secretbox_NONCEBYTES;

    unsigned char key_bin[crypto_secretbox_KEYBYTES];
    crypto_generichash(key_bin, sizeof key_bin, (const unsigned char *)key, strlen(key), NULL, 0);

    unsigned char *decrypted = malloc(cipherLen);
    if (crypto_secretbox_open_easy(decrypted, cipher, cipherLen, nonce, key_bin) != 0) {
        fprintf(stderr, "Decryption failed.\n");
        free(decrypted);
        free(data);
        stbi_image_free(img);
        return NULL;
    }

    // Ensure null termination
    decrypted[cipherLen - crypto_secretbox_MACBYTES] = '\0';

    free(data);
    stbi_image_free(img);
    return (char *)decrypted;
}


