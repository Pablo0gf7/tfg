#ifndef LSB3_H
#define LSB3_H

#include <stddef.h>

void embedMessage(const char *imagePath, const char *message, const char *outputPath, const char *key);
char *extractMessage(const char *imagePath, const char *key);


#endif // LSB3_H